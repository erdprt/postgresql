CREATE USER MAPPING FOR same_role_1 SERVER server1 OPTIONS(user 'maria', password 'test');
CREATE USER MAPPING FOR same_role_2 SERVER server2 OPTIONS(user 'eva');
