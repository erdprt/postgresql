CREATE INDEX same_index_1 ON products(actor);

CREATE INDEX from_index_1 ON customers(country);
