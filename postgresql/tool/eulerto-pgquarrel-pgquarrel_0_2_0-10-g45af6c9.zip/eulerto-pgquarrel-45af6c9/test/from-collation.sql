CREATE COLLATION same_collation_1 FROM "pt_BR";

CREATE COLLATION from_collation_1 (LOCALE = 'en_US.UTF-8');
