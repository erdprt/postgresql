CREATE USER MAPPING FOR same_role_1 SERVER server1 OPTIONS(user 'mane', password 'senha');
CREATE USER MAPPING FOR same_role_3 SERVER server3;
