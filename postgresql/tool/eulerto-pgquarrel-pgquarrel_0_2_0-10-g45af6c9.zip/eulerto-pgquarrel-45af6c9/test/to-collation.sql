CREATE COLLATION same_collation_1 FROM "pt_BR";

CREATE COLLATION to_collation_1 (LC_COLLATE = 'en_US.UTF-8', LC_CTYPE = 'C.UTF-8');
