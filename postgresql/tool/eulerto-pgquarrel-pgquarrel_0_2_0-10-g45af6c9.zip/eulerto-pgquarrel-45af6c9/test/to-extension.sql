CREATE EXTENSION pgstattuple;
CREATE EXTENSION pg_buffercache;
