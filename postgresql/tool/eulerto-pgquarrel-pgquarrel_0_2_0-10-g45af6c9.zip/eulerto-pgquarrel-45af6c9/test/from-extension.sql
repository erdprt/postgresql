CREATE EXTENSION pg_trgm;
CREATE EXTENSION pg_stat_statements;
